---
name: "Feature request \U0001F680"
about: Suggest an idea for this project
title: 'Feature Request'
labels: 'needs triage :warning:'
assignees: ''

---

<!-- Please read our Rules of Conduct: https://opensource.microsoft.com/codeofconduct/ -->
<!-- Please search existing issues to avoid creating duplicates. -->

**Describe the solution you'd like**

