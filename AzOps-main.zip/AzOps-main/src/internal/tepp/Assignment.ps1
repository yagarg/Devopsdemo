﻿<#
# Example:
Register-PSFTeppArgumentCompleter -Command Get-Test -Parameter Type -Name AzOps.x
#>