﻿<#
# Example:
Register-PSFTeppScriptblock -Name "AzOps.Test" -ScriptBlock { 'Test' }
#>