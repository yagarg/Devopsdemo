# Welcome to the AzOps Wiki

These pages are used as the core documentation for the project.

Please refer to the sidebar (on the right) for details on the Getting Started, Additional Documentation and Contributing Guides.

If you'd like to contribute to the Wiki, please fork the AzOps repository and edit the Wiki pages within the `docs/wiki` directory.

For an up-to-date view on active work items, please visit the Project [board](https://github.com/Azure/AzOps/projects/2)
