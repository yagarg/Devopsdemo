### In this section

- [GitHub Actions](https://github.com/azure/azops/wiki/github-actions)
- [Azure Pipelines](https://github.com/azure/azops/wiki/azure-pipelines)
